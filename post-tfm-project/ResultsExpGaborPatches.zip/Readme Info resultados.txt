Cada fichero de resultados contiene evaluaciones de 360 pares de imágenes (360 filas)
También contiene 2 columnas: La primera columna es la tasa de acierto y la segunda el tiempo promedio necesitado para elegir

Los 360 pares contienen imágenes con 10 niveles de ruido con los que comparar, 3 niveles de ruido base, 3 orientaciones del parche y 4 frecuencias espaciales

Las imágenes con frecuencia del parche de gabor 0.5 dva son las 1-90, 
Las imágenes con frecuencia del parche de gabor 2 dva son las 91-180, 
Las imágenes con frecuencia del parche de gabor 5 dva son las 181-270, 
Las imágenes con frecuencia del parche de gabor 8 dva son las 271-360, 

En cada grupo de 90, las primeras 30 son con orientación horizontal 
las segundas 30 con orientación diagonal 
las últimas 30 con orientación horizontal 

En cada grupo de 30, las primer 10 son niveles de ruido 0.02, las siguientes 10 0.04 y las últimas 10, 0.08






